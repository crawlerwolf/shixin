CREATE TRIGGER TRIG_DEAL_RECORD
BEFORE INSERT
  ON YZZD_T_ORDER
FOR EACH ROW
  declare user_yue number;
    begin
  --update yzzd_t_user u set u.blance = u.blance - :new.money where u.id= :new.userid;   
  select tu.blance
    into user_yue
    from yzzd_t_user tu
   where tu.id = :new.userid;
  insert into yzzd_t_deal_record
    (id,
     tuser_id,
     deal_type,
     product_id,
     amount,
     tuser_yue,
     deal_time,
     create_user,
     description)
  values
    (:new.id, :new.userid,'0',:new.productid,:new.money,user_yue,:new.createtime,'sys','查询订单');
    end;
/
